#Создай собственный Шутер!
from Pygame import *
from random import randint
from time import time as timer
font.init()
#счетчик
lost = 0 #пропущено
die = 0
magazin = 5
reloadd = False
#класс
class GameSprite(sprite.Sprite):
    def __init__(self, player_image, player_x, player_y, player_speed):
        super().__init__()
        self.image = transform.scale(image.load(player_image), (90,90))
        self.speed = player_speed
        self.rect = self.image.get_rect()
        self.rect.x = player_x
        self.rect.y = player_y
    def reset(self):
        window.blit(self.image, (self.rect.x, self.rect.y)) 

class Player(GameSprite): 
    def __init__(self, player_image, player_x, player_y, player_speed): 
        super().__init__(player_image, player_x, player_y, player_speed) 
    def update(self): 
        keys = key.get_pressed() 
        if keys[K_a] and self.rect.x > 0: 
            self.rect.x -= self.speed 
        if keys[K_d] and self.rect.x < 700: 
            self.rect.x += self.speed
    def fire(self):
        bullet = Bullet('heart.png', self.rect.centerx, self.rect.top, -5)
        bullet.reset()
        bullets.add(bullet)
class Wall(sprite.Sprite):
    def __init__(self, color_1, color_2, color_3, wall_x, wall_y, wall_width, wall_height):
        super().__init__()
        self.color_1 = color_1
        self.color_2 = color_2
        self.color_3 = color_3
        self.width = wall_width
        self.height = wall_height
        self.image = Surface((self.width, self.height))
        self.image.fill((color_1, color_2, color_3))
        self.rect = self.image.get_rect()
        self.rect.x = wall_x
        self.rect.y = wall_y
    def draw_wall(self):
        window.blit(self.image, (self.rect.x, self.rect.y))
class Enemy(GameSprite):
    def __init__(self, player_image, player_x, player_y, player_speed):
        super().__init__(player_image, player_x, player_y, player_speed)
    def update(self):
        self.rect.y += self.speed
        global lost
        if self.rect.y > 700:
            self.rect.y = 0 
            self.rect.x = randint(80,620)
            lost = lost + 1
class Bullet(GameSprite):
    def __init__(self, player_image, player_x, player_y, player_speed):
        super().__init__(player_image,player_x, player_y, player_speed)
        self.image = transform.scale(image.load(player_image), (40, 40))
        
    def update(self):
        self.rect.y += self.speed
        if self.rect.y <= 0:
            self.kill()
            
font1 = font.Font(None, 34)
font2 = font.Font(None, 134)
lose = font2.render('YOU LOSE!', True, (255, 0 ,0))
win = font2.render('YOU WIN!', True, (50, 205 ,50))
monsters = sprite.Group()
monster1 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster2 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster3 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster4 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster5 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster6 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monster7 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
monsters.add(monster1)
monsters.add(monster2)
monsters.add(monster3)
monsters.add(monster4)
monsters.add(monster5)
monsters.add(monster6)
monsters.add(monster7)
bullets = sprite.Group()
enemys = sprite.Group()
enemy1 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
enemy2 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
enemy3 = Enemy('sprite2.png', randint(80,620),0,randint(1,5))
enemys.add(enemy1)
enemys.add(enemy2)
enemys.add(enemy3)

#создай окно игры

window = display.set_mode((700,700))
display.set_caption("Шутер")
background = transform.scale(image.load("back1.png"), (700,700))
player = Player("legend.png",310, 510, 10)



FPS = 60
clock = time.Clock()
speed = 5
clock.tick(60)
#музыка
mixer.init()
mixer.music.load("space.ogg")
mixer.music.play()
fire = mixer.Sound('fire.ogg')
#win = mixer.Sound('sound.mp3')
run = True
finish = False
while run != False:
    for e in event.get():
        if e.type == QUIT:
            run = False
        if reloadd == False:
            if e.type == KEYDOWN and e.key == K_SPACE:
           
                    fire.play()
                    player.fire()
                    magazin -= 1
                    if magazin  <= 0 and reloadd == False:
                        start = timer()
                        reloadd = True
     
    if finish != True:
        text_lose = font1.render("Пропущено:" + str(lost), 1 , (71, 11, 24))
        text_win = font1.render("Счет:" + str(die), 1 , (71, 11, 24))
        window.blit(background,(0, 0))
        player.update()
        player.reset()
        monsters.update()
        monsters.draw(window)
        enemys.update()
        enemys.draw(window)
        window.blit(text_lose,(20, 70))
        window.blit(text_win,(20, 40))
        bullets.draw(window)
        bullets.update()
        collides = sprite.groupcollide(monsters, bullets, True, True)
        for c in collides:
            die += 1
            monster8 = Enemy('pngegg.png', randint(80,620),0,randint(1,5))
            monsters.add(monster8)
        if die >= 10:
            #win.play()
            finish = True
            window.blit(win, (170, 200))

    
        #if die >= 10:
            #win.play()
            #finish = True
            #window.blit(win, (170, 200))
        if reloadd == True:
            end = timer()
            print(end, start)
            if end - start >= 1:
                magazin = 5
                reloadd = False 
           
        if sprite.spritecollide(player, monsters, False) or lost >= 3 or sprite.spritecollide(player, enemys, False):
            
            window.blit(lose, (170, 200))
            finish = True
        sprites_list = sprite.groupcollide(monsters, bullets, True, True)
        
        


    display.update()
    